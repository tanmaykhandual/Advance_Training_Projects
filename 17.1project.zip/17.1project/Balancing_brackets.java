package problem17;
import java.util.Scanner;
import java.util.Stack;

public class Balancing_brackets {
	public static boolean isBalanced(String expression) {
		  if ((expression.length() % 2) == 1) return false;
		  else {
		    Stack<Character> s = new Stack<>();
		    for (char bracket : expression.toCharArray())
		      switch (bracket) {
		        case '{': s.push('}'); break;
		        case '(': s.push(')'); break;
		        case '[': s.push(']'); break;
		        default :
		          if (s.isEmpty() || bracket != s.peek()) { return false;}
		          s.pop();
		      }
		    return s.isEmpty();
		  }
		}
	
	public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
	    System.out.println("Enter the expression");
	    String expression = scan.nextLine();
	    boolean answer = isBalanced(expression);
	    if (answer) { System.out.println("Balanced");}
	    else { System.out.println("Not Balanced");}

	}

}

